<?php
include "koneksi.php";
$sqlp=mysql_query("select * from pemesanan where kdpemesanan='$_GET[kdp]'");
while($rp2=mysql_fetch_array($sqlp)){
  $total=$total+$rp2[harga2];
  $kdpemesanan=$rp2[kdpemesanan];
}
$sqlp=mysql_query("select * from pemesanan where kdpemesanan='$_GET[kdp]'");
$rp=mysql_fetch_array($sqlp);
?>
<div class="container4">
  <div class="transtop">TRANSAKSI</div>
  <div class="grid">
    <p align="center" style="margin-top:-0px;">
    COD / Pembayaran dilakukan ketika mekanik kami telah menyelesaikan pekerjaannya.</br>
    Mengenai harga akan ditetapkan oleh mekanik tersebut</br>
    </p>
    <div class="dh12">
	  <div class="dh6">
	    <div id="border" style="min-height:280px;">
          <div class="transtop">Penerima</div>
          <p style="padding-left:10px;">Nama : <?php echo "$rp[nama]"; ?></p>
          <p style="padding-left:10px;">Alamat : <?php echo "$rp[alamat]"; ?></p>
          <p style="padding-left:10px;">Nohp : <?php echo "$rp[nohp]"; ?></p>
          <p style="padding-left:10px;">Catatan : <?php echo "$rp[catatan]"; ?></p>
		</div>
	  </div>
	  <div class="dh6">
	    <div id="border" style="min-height:280px;">
          <div class="transtop">Pemesan</div>
          <p style="padding-left:10px;">Nama : <?php echo "$rm[nama]"; ?></p>
          <p style="padding-left:10px;">Alamat : <?php echo "$rm[alamat]"; ?></p>
          <p style="padding-left:10px;">Nohp : <?php echo "$rm[nohp]"; ?></p>
		</div>
	  </div>
    </div>
	<p style="font-size:14px;padding-left:10px;">Nb:</br>
	status transaksi anda masih <b style="color:red">belum disubmit</b>, sampai anda membayarnya. Pemesanan dapat dibatalkan oleh admin sewaktu waktu, selama mekanik belum mengerjakannya.</p>
	<p align="center">Apakah anda yakin?</p>
	<form name="formyakin" method="post" action="" enctype="multipart/form-data">
	<div class="dh6" align="center">
	  <p><input name="ryakin" type="radio" value="yes"></p>
	  <p style="margin-top:-10px;">YES</p>
	</div>
	<div class="dh6" align="center">
	  <p><input name="ryakin" type="radio" value="no"></p>
	  <p style="margin-top:-10px;">NO</p>
	</div>
	<div align="center"><input type="submit" name="submitcod" value="SUBMIT"/></div>
	</form>
  </div>
  <?php
  if($_POST["submitcod"]&&$_POST["ryakin"]=="yes"){
	$sqlp=mysql_query("update pemesanan set status='cash' where kdpemesanan='$kdpemesanan'");
	echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=pemesanan'>";
	echo "yes";
  }else if($_POST["submitcod"]&&$_POST["ryakin"]=="no"){
	echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=pemesanan'>";
  }
  ?>
</div>