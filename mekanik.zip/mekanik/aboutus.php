<div align="center" style="border:1px solid #000;color:#fff;">
  <p style="background-color:#388850;margin-top:0px;margin-bottom:0px"><img src="images/logo2.png" width="500px"></p>
  <p style="background-color:#505050;margin-top:0px;margin-bottom:0px;font-family:Hobo Std;"><u>BENGKELKU</u></p>
  <p style="background-color:#B0B0B0;color:#000;margin-top:0px;margin-bottom:0px;">
    </br>
	BENGKELKU adalah </br>
    Sistem Mekanik Terbaik Dan Cepat</br>
	Ayo Daftarkan diri anda</br>
  </p>
</div>