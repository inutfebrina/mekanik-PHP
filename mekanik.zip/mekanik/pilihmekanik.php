<?php
include "koneksi.php";
?>
<?php
$sqlmkn = mysql_query("select * from mekanik order by idmekanik asc");

while($rmkn = mysql_fetch_array($sqlmkn)){
echo "<div class='dh6' align='center'>";
echo "<div id='prd'>";
echo "<fieldset>";
echo "<img src='fotomekanik/$rmkn[foto]' width='40%'>";
echo "<h3>$rmkn[namamekanik]</h3>";
echo "<p><a href='?p=mekanik&idmkn=$rmkn[idmekanik]'><button type='button' class='btn btn-more'>Lihat Mekanik</button></a>";
echo "</fieldset>";
echo "</div>";
echo "</div>";
}
?>