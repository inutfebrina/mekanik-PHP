<div class="container-pesan">
  <div class="top-pesan">
    Lakukan Pemesanan
  </div>
  <div class="grid">
    <div class="dh12">
      <div class="dh6">
	    <b>Mekanik</b>
		<table id='wborder2' border="0" width="100%" cellpadding="10" align="center">
		  <tr>
		    <th>No</th>
			<th>Nama</th>
			<th>NoHP</th>
		  </tr>
		  <?php
		  $sqlk = mysql_query("select * from keranjang where idmember = '$rm[idmember]'");
		  $no=0;
		  while($rk = mysql_fetch_array($sqlk)){
		  	$sqlmk = mysql_query("select * from mekanik where idmekanik='$rk[idmekanik]'");
		  	$rmk=mysql_fetch_array($sqlmk);
		  	$no++;
		  	echo "<tr>";
		  	echo "<td>$no</td>";
		  	echo "<td>$rmk[namamekanik]</td>";
		  	echo "<td>$rmk[nohp]</td>";
		  	echo "</tr>";
			echo "<input name='idmekanik' id='idmekanik' type='hidden' value='$rmk[idmekanik]'>";
		  }
		  ?>
		</table>
	  </div>
	  <div class="dh6">
	    <p><b>Nama Pemesan : </b><b style="color:red;"><?php echo"$rm[nama]"; ?></b></p>
		<p><b>Nohp : </b><b style="color:red;"><?php echo"$rm[nohp]"; ?></b></p>
		<form name="formmasukkandatasaya" method="post" action="" enctype="multipart/form-data">
		<input name="btn0" id="btn0" type="submit" value="Masukan Data Saya">
		</form>
		<?php
		$nama="";
		$nohp="";
		$alamat="";
		if(isset($_POST["btn0"])){
		if($_POST["btn0"]){
		  $nama="$rm[nama]";
		  $nohp="$rm[nohp]";
		  $alamat="$rm[alamat]";
		}
		}
		$kd = "ORDER";
		$d = date("d");
		$m = date("m");
		$y = date("Y");
		$j = date("h");
		$mi = date("i");
		$s = date("s");
		?>
	  </div>
	</div>
	<div class="dh12">
	  <div class="isipesan">
	    <form name="formpesan" method="post" action="" enctype="multipart/form-data">
		<input name="idmember" id="idmember" type="hidden" value="<?php echo "$rm[idmember]"; ?>">
		<input name="kdpemesanan" type="hidden" value="<?php echo "$kd-$y$m$d$j$mi$s"; ?>">
	    <p>
	    <div class="dh4">
		  Nama Penerima :
		  <input name="nama" id="nama" type="input" value="<?php echo "$nama"; ?>">
		</div>
		<div class="dh4">
		  No.Hp Penerima :
		  <input name="nohp" id="nohp" type="input" value="<?php echo "$nohp"; ?>">
		</div>
		</p>
		<p style="padding-top:30px;"></p>
		<div class="dh12">
		  <p>Alamat Penerima
		    <textarea name="alamat" id="alamat"></textarea>
		  </p>
		</div>
		<p style="padding-top:10px;"></p>
		<div class="dh12">
		  <p>Catatan Untuk Mekanik
		    <textarea name="catatan" id="catatan"></textarea>
		  </p>
		</div>
		<p style="padding-top:10px;"></p>
		<div class="dh12">
		  <p>
		  <input name="submit" id="submit" type="submit" value="SUBMIT">
		  </p>
		</div>
		</form>
		<p>&nbsp;
		<?php
		if(isset($_POST["submit"])){
		if($_POST["submit"]){
		  if($_POST["nama"]!=null&&$_POST["nohp"]!=null&&$_POST["alamat"]!=null){
			$sqlk2 = mysql_query("select * from keranjang where idmember = '$rm[idmember]'");
			while($rk2=mysql_fetch_array($sqlk2)){
			  $sqlmk0 = mysql_query("select * from mekanik where idmekanik='$rk2[idmekanik]'");
			  $rmk0 = mysql_fetch_array($sqlmk0);
			  $sqlp = mysql_query("insert into pemesanan (idmember, idmekanik, kdpemesanan, nama, nohp, alamat, catatan, tglpemesanan) values ('$_POST[idmember]', '$rk2[idmekanik]', '$_POST[kdpemesanan]', '$_POST[nama]', '$_POST[nohp]', '$_POST[alamat]', '$_POST[catatan]', NOW())");
			  if($sqlp){
				$sqlmk = mysql_query("select * from mekanik where idmekanik='$rk2[idmekanik]'");
				$rmk = mysql_fetch_array($sqlmk);
				$statusnow = "OnProcess";
				$sqlmk2 = mysql_query("update mekanik set status='$statusnow' where idmekanik='$rmk[idmekanik]'");
				$sqlk3 = mysql_query("delete from keranjang where idkeranjang='$rk2[idkeranjang]'");
				echo "Pesanan Telah Dilakukan -Harap Menunggu- !!!";
			  }else{
			    echo "GAGAL";
			  }
			}
		  }else{
			echo "Data Tidak Lengkap!!!";
		  }
		  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=pemesanan'>";
		}
		}
		?>
		</p>
	  </div>
	</div>
  </div>
</div>