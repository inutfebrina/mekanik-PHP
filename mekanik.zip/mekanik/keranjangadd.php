<?php
if(!empty($_SESSION["usermbr"]) and !empty($_SESSION["passmbr"])){
  include "koneksi.php";
  $sqlmk = mysql_query("select * from mekanik where idmekanik='$_GET[idmk]'");
  $rmk = mysql_fetch_array($sqlmk);
  if($rmk["status"]=="Standby" || $rmk["status"]==""){
	$sqlk = mysql_query("select * from keranjang where idmember = '$rm[idmember]' and idmekanik='$rmk[idmekanik]'");
	$status=0;
	while($rk = mysql_fetch_array($sqlk)){
	  if($rk["idmekanik"]==$rmk["idmekanik"] || $rmk["idmekanik"] == "On Process" ){
		$status = 1;
	  }else if($rk["idmekanik"]!=$rmk["idmekanik"]){
	    $status = 0;
	  }
	}
	if($status == 0){
	  $sqlk2 = mysql_query("insert into keranjang (idmember, idmekanik) values ('$rm[idmember]', '$rmk[idmekanik]')");
      if($sqlk2){
        echo "Mekanik anda telah ditambah";
      }else{
        echo "gagal menambah";
      }
    }else{
	  echo "mekanik $rmk[namamekanik] sudah ada dalam keranjang, silahkan cari yg lain";
	}
  }else{
	echo "mekanik Sedang Dipakai!!!";
  }
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=keranjang'>";
}else{
  echo "Anda Harus Login atau Register Terlebih Dahulu";
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=register'>";
}
?>