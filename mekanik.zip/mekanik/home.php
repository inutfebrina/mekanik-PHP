   <p><img src="image/ketek.jpg" width="100%">
  <div class="dh12" align="justify">
</p>
<div class="dh12" align="center">
  <h3>Mengapa di BENGKELKU?</h3>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
  
   <div class="dh4" align="center">
  <img src="image/icon3.png" width="35%">
  <p><strong><big>Servis Jadi Mudah</big>
  </strong>
  <p>Pesan sekarang dan mekanik kami akan datang ke manapun dan kapanpun.
  </div>
  
  <div class="dh4" align="center">
  <img src="image/icon1.png" width="35%">
  <p><strong><big>Harga Lebih Murah dan Jujur</big>
  </strong>
  <p>Pelayanan Cepat mudah dan harga terbaik.
  </div>
  
  <div class="dh4" align="center">
  <img src="image/icon2.png" width="35%">
  <p><strong><big>Mengutamakan Kepuasan Pelanggan</big>
  </strong>
  <p>Kepuasan pelanggan adalah No 1 bagi kami. 
  <p>  
  <p>
  </div>