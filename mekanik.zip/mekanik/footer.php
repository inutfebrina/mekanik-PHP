<div class="dh12" align="center">Contact Us</div>
<div class="dh10" style="width:97%" align="center">
  <div class="dh3">
    <img src="medsos/fb.png" width="100px"/></br>
	<span>Muhammad Mirwan</span>
  </div>
  <div class="dh3">
    <img src="medsos/wa.png" width="100px"/></br>
	<span>082282365498</span>
  </div>
  <div class="dh3">
    <img src="medsos/ig.png" width="100px"/></br>
	<span>muhammadmirwann</span>
  </div>
  <div class="dh3">
    <img src="medsos/hp.png" width="100px"/></br>
	<span>082282365498</span>
  </div>
</div>

<div class="dh12">
  <div class="dh6" align="left">
  <h4>&copy; 2018 BENGKELKU</h4>
  <p>Design and develop by Muhammad Mirwan<br>
  All logos and trademarks mentioned herein are the registered property of their respective companies.  
  </div>
  
  <div class="dh6" align="right">
  <h4>BENGKELKU</h4>
  <p>Jln. Aru Indah, Komplek Pemda No 51.A, Padang, Sumatera Barat, Indonesia<br>
  Telp : 082282365498<br>
  email : mirwanmuhammad44@gmail.com
  </div>
</div>