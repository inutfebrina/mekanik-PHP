<?php
include "koneksi.php";
$sqlp= mysql_query("select * from pemesanan where kdpemesanan = '$_GET[kdp]'");
?>
<fieldset style="width:92.2%;margin-top:-32px;>
<form name="form1" method="post" action="" enctype="multipart/form-data">
  <p>Harga</br>
    <input name="harga" type="text" id="harga" style="width:97.2%;">
  </p>
  <p align="center" style="color:#F00;">
  <input name="selesai" type="submit" id="selesai" value="SELESAI" />
</form>

<?php
if($_POST["selesai"]){
  $totalbayar=$_POST["harga"];
$sqlp2= mysql_query("select * from pemesanan where kdpemesanan = '$_GET[kdp]'");
$rp2=mysql_fetch_array($sqlp2);
$sqlt=mysql_query("insert into transaksi (idmember, kdpemesanan, totalbayar, tgltransaksi) values ('$rp2[idmember]', '$rp2[kdpemesanan]', '$totalbayar', NOW())");
$sqlp3=mysql_query("update pemesanan set harga ='$totalbayar', status='sudah' where kdpemesanan='$_GET[kdp]'");
 
 echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=pemesanan'>";
}
?>
</p>
</fieldset>