<?php
include "koneksi.php";
$sqlmk = mysql_query("select * from mekanik where idmekanik = '$_GET[idmk]'");
$rmk=mysql_fetch_array($sqlmk);
?>
<fieldset style="width:92.2%;margin-top:-32px;">
<form name="form1" method="post" action="" enctype="multipart/form-data">
  <p align="center" style="background-color:#494949;color:#fff;font-family:Hobo Std;font-size:20px;box-shadow:0 0 2px #000;width:99.8%;"><u>UBAH DATA MEKANIK</u></p>
  <input type="hidden" name="idmekanik" value="<?php echo "$rmk[idmekanik]"; ?>">
  <p>Username</br>
    <input name="username" type="text" id="username" style="width:97.2%;" value="<?php echo "$rmk[username]" ?>">
  </p>
  <p>Password</br> 
    <input name="password" type="password" id="password" style="width:97.2%;" value="<?php echo "$rmk[password]" ?>">
  </p>
  <p>Konfirmasi Password</br>
    <input name="password2" type="password" id="password" style="width:97.2%;" value="<?php echo "$rmk[password]" ?>">
  </p>
  <p>Nama Lengkap</br>
    <input name="nama" type="text" id="nama" style="width:97.2%;" value="<?php echo "$rmk[namamekanik]" ?>">
  </p>
  <?php
  if($rm["jk"] == "L"){
  	$l = " checked";   $p = "";
  }else if($rm["jk"] == "P"){
  	$l = "";   $p = " checked";
  }else{
  	$l = "";   $p = "";
  }
  ?>
  <p>JENIS KELAMIN 
    <input name="jk" type="radio" value="L" <?php echo "$l"; ?> >
    Laki-Laki
    <input name="jk" type="radio" value="P" <?php echo "$p"; ?> >
    Perempuan
  </p>
  <p>No HP</br>
    <input name="nohp" type="text" id="nohp" style="width:97.2%;" value="<?php echo "$rmk[nohp]" ?>">
  </p>
  <p>Foto</br>
  <input name="foto" type="file" id="foto" />
  <p>&nbsp;</p>
  <p>
    <input name="update" type="submit" id="update" value="UPDATE DATA MEKANIK">
</p>
</form>
<p align="center" style="color:#F00;">
<?php
if($_POST["update"]){
  if($_POST[username]!=null&&$_POST[password]!=null&&$_POST[nama]!=null){
	if($_POST[password]==$_POST[password2]){
	  include "koneksi.php";
	  $nmfoto = $_FILES["foto"]["name"];
	$lokfoto = $_FILES["foto"]["tmp_name"];
	if(!empty($lokfoto)){
		move_uploaded_file($lokfoto, "../fotomekanik/$nmfoto");
		$foto = ", foto='$nmfoto'";
		}else{
		$foto ="";
		}
	  $sqlmk = mysql_query("update mekanik set username='$_POST[username]', password='$_POST[password]', namamekanik='$_POST[nama]', jk='$_POST[jk]', nohp='$_POST[nohp]' $foto where idmekanik='$_POST[idmekanik]'");
	  if($sqlmk){
		echo "Data Mekanik Telah Diupdate";
	  }else{
		echo "Data Mekanik Gagal Diupdate!!!";
	  }
	echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=mekanik'>";
	}else{
	  echo "Password tidak Cocok!!!";
	}
  }else{
	echo "Data Tidak Lengkap!!!";
  }
}
?>