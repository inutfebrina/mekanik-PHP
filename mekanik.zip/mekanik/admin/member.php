<?php
include "koneksi.php";
$sqlm = mysql_query("select * from member order by idmember asc");
?>
<p></p>
<table id="wborder" border="1" width="90%" cellpadding="10">
  <tr>
   <th>NO</th>
   <th>USERNAME</th>
   <th>PASSWORD</th>
   <th>NAME</th>
   <th>NOHP</th>
   <th>EMAIL</th>
   <th>ACTION</th>
  </tr>
<?php
$no=0;
while($rm = mysql_fetch_array($sqlm)){
  $no++;
  echo 
 "<tr height='50px'>
    <td>$no</td>
	<td>$rm[username]</td>
    <td>$rm[password]</td>
    <td>$rm[nama]</td>
	<td>$rm[nohp]</td>
	<td>$rm[email]</td>
	<td>
	  <a href='?p=memberdel&idm=$rm[idmember]'>Hapus</a>
	</td>
  </tr>";
  }
?>
</table>