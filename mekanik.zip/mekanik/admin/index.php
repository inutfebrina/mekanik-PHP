<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<title>BENGKELKU</title>
</head>
<?php
if(!empty($_SESSION["useradm"]) and !empty($_SESSION["passadm"])){
?>
<body>
<form name="form0" method="post" action="" enctype="multipart/form-data">
<div class="container1">
  <div id="judul">
	Welcome Administrator
  </div>
</div>
<div class="container2">
  <div class="grid">
    <div class="dh3">
      <ul id="menu">
        <li><a href="<?php echo"?p=home"; ?>">Beranda</a></li>
	    <li><a href="<?php echo"?p=pemesanan"; ?>">Pemesanan</a></li>
	    <li><a href="<?php echo"?p=transaksi"; ?>">Transaksi</a></li>
        <li><a href="<?php echo"?p=admin"; ?>">Admin</a></li>
	    <li><a href="<?php echo"?p=mekanik"; ?>">Mekanik</a></li>
        <li><a href="<?php echo"?p=member"; ?>">Member</a></li>
	    <li><a href="<?php echo"?p=logout"; ?>">Logout</a></li>
      </ul>
    </div>
    
    <div class="dh9">
	  <div id="isiadmin">
		<?php
		  if($_GET["p"] == "logout"){
		 	 include "logout.php"; 
		  }else if($_GET["p"] == "pemesanan"){
		 	 include "pemesanan.php"; 
		  }else if($_GET["p"] == "transaksi"){
		 	 include "transaksi.php";
		  }else if($_GET["p"] == "admin"){
		 	 include "admin.php";
		  }else if($_GET["p"] == "adminadd"){
		 	 include "adminadd.php";
		  }else if($_GET["p"] == "admindel"){
		 	 include "admindel.php";
		  }else if($_GET["p"] == "adminedit"){
		 	 include "adminedit.php";
		  }else if($_GET["p"] == "mekanik"){
		 	 include "mekanik.php";
		  }else if($_GET["p"] == "mekanikadd"){
		 	 include "mekanikadd.php";
		  }else if($_GET["p"] == "mekanikedit"){
		 	 include "mekanikedit.php";
		  }else if($_GET["p"] == "mekanikdel"){
		 	 include "mekanikdel.php";
		  }else if($_GET["p"] == "codsubmit"){
		 	 include "codsubmit.php";
		  }else if($_GET["p"] == "bayarsubmit"){
		 	 include "bayarsubmit.php";
		  }else if($_GET["p"] == "member"){
		 	 include "member.php";
		  }else if($_GET["p"] == "memberdel"){
		 	 include "memberdel.php";
		  }else if($_GET["p"] == "home"){
		 	 include "home.php";
		  }
		?>
      </div>
    </div>
    
  </div>
</div>

</form>
</body>
<?php
}else if(!empty($_SESSION["usermkn"]) and !empty($_SESSION["passmkn"])){
  include "indexmekanik.php";
}else{
  include "login.php";
}  
?>

</html>
