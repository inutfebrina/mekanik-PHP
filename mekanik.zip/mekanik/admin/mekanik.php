<?php
include "koneksi.php";
$sqlmk = mysql_query("select * from mekanik order by idmekanik asc");
?>
<a href="<?php echo "?p=mekanikadd"; ?>">Tambah Mekanik</a>
<p></p>
<table id="wborder" border="1" width="90%" cellpadding="10">
  <tr>
   <th>NO</th>
   <th>USERNAME</th>
   <th>PASSWORD</th>
   <th>NAME</th>
   <th>JK</th>
   
   <th>NOHP</th>
   <th>FOTO</th>
   <th>ACTION</th>
  </tr>
<?php
$no=0;
while($rmk = mysql_fetch_array($sqlmk)){
  $no++;
  echo 
 "<tr height='50px'>
    <td>$no</td>
    <td>$rmk[username]</td>
    <td>$rmk[password]</td>
    <td>$rmk[namamekanik]</td>
	<td>$rmk[jk]</td>

	<td>$rmk[nohp]</td>
    <td>
	<img src='../fotomekanik/$rmk[foto]' width='120px'><p>
	</td>
	<td>
	  <a href='?p=mekanikedit&idmk=$rmk[idmekanik]'>Ubah</a> |
	  <a href='?p=mekanikdel&idmk=$rmk[idmekanik]'>Hapus</a>
	</td>
  </tr>";
  }
?>
</table>