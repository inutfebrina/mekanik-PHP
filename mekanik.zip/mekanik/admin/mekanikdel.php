<?php 
  include "koneksi.php";
  $sqlmk = mysql_query("delete from mekanik where idmekanik='$_GET[idmk]'"); 
  if($sqlmk){ 
  	echo "Data Berhasil Dihapus";
  }else{
  	echo "Gagal Menghapus Data";
  }
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=mekanik'>"; 
?>
