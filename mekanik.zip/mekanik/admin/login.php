<div class="container">
  <div id="loginadmin" align="center" style="margin-top:150px;">
    <fieldset style="width:500px;padding:10px 10px 10px 10px;background-color:#fff;">
      <form name="form1" method="post" action="" enctype="multipart/form-data">
        <h3 style="color:blue"><u>BENGKELKU</u></h3>
        <p>Username
          <input name="username" type="text" id="username" >
        </p>
        <p>Password
          <input name="password" type="password" id="password" >
        </p>
        <p>
          <label>
          <input type="radio" name="radio" id="radio" value="admin" />
          Admin</label>
           <label>
          <input type="radio" name="radio" id="radio" value="mekanik" />
          Mekanik</label>
        </p>
        <p>
          <input name="login" type="submit" value="LOGIN">
        </p>
      </form>
        
      <?php
	  if(isset($_POST["login"])){
      if($_POST["login"]){
	    if($_POST["radio"]=="admin"){
	  
          include "koneksi.php";
          $sqla = mysql_query("select * from admin where username='$_POST[username]' and password='$_POST[password]'");
      	  $ra = mysql_fetch_array($sqla);
      	  $row = mysql_num_rows($sqla);
      	  if($row > 0){
      	    session_start();
      	    $_SESSION["useradm"]=$ra["username"];
      	    $_SESSION["passadm"]=$ra["password"];
      	    echo "Login Berhasil";	
		    echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=home'>";
      	  }else{
      	    echo "Login Gagal";
		    echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=login'>";
      	  }
	    }else if($_POST["radio"]=="mekanik"){
		  include "koneksi.php";
          $sqlmk = mysql_query("select * from mekanik where username='$_POST[username]' and password='$_POST[password]'");
      	  $rmk = mysql_fetch_array($sqlmk);
      	  $row = mysql_num_rows($sqlmk);
      	  if($row > 0){
      	    session_start();
      	    $_SESSION["usermkn"]=$rmk["username"];
      	    $_SESSION["passmkn"]=$rmk["password"];
      	    echo "Login Berhasil";	
		    echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=home'>";
      	  }else{
      	    echo "Login Gagal";
		    echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=login'>";
      	  }
		}
	  }
      }
	  
      ?>
      
    </fieldset>
  </div>
</div>