<?php
include "koneksi.php";
$sqlm = mysql_query("delete from member where idmember='$_GET[idm]'");
$sqlo = mysql_query("delete from lastonline where idmember='$_GET[idm]'");
if($sqlm){
  	echo "Member berhasil dihapus";
  }else{
  	echo "Gagal Menghapus Member";
  }
echo "<META HTTP-EQUIV='Refresh' Content='1; url=?p=member'>";
?>