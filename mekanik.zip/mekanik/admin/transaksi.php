<?php include "koneksi.php"; ?>
<p>
<table id="wborder2" border="1" width="90%" cellpadding="10">
<tr>
  <th width="10px">NO</th>
  <th width="250px">Nama Member</th>
  <th>Jenis Pembayaran</th>
  <th>Total Bayar</th>
  <th>Tanggal Transaksi</th>
</tr>
<?php
  $sqlt = mysql_query("select * from transaksi order by idtransaksi asc");
  $no = 1;
  $totalpemasukan=0;
  while($rt = mysql_fetch_array($sqlt)){
	$sqlm=mysql_query("select * from member where idmember = '$rt[idmember]'");
	$rm=mysql_fetch_array($sqlm);
	  $jenisbayar="CASH";
	
    echo "
	<tr>
	  <td>$no</td>
	  <td>$rm[nama]</td>
	  <td>$jenisbayar</td>
	  <td>Rp.$rt[totalbayar]</td>
	  <td>$rt[tgltransaksi]</td> 
	</tr>";
	$no++;
	$totalpemasukan=$totalpemasukan+$rt[totalbayar];
  }
?>
</table>
<?php
echo "<div align='center' style='background-color:#999999;color:blue;font-size:20px;width:99.7%;'><b>Total Pemasukan Saat ini: Rp.$totalpemasukan</b></div>";
?>