<?php
  session_start();
  session_destroy();
  echo "Logging out";
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=login'>";
?>