<?php

	  include "koneksi.php";
?>
<fieldset style="width:92.2%;margin-top:-32px;>
<form name="form1" method="post" action="" enctype="multipart/form-data">
  <p align="center" style="background-color:#494949;color:#fff;font-family:Hobo Std;font-size:20px;box-shadow:0 0 2px #000;width:99.8%;"><u>TAMBAH DATA MEKANIK</u></p>
  <p>Username</br>
    <input name="username" type="text" id="username" style="width:97.2%;">
  </p>
  <p>Password</br> 
    <input name="password" type="password" id="password" style="width:97.2%;">
  </p>
  <p>Konfirmasi Password</br>
    <input name="password2" type="password" id="password" style="width:97.2%;">
  </p>
  <p>Nama Lengkap</br>
    <input name="nama" type="text" id="nama" style="width:97.2%;">
  </p>
 
  <p style="margin-left:20px;">Jenis Kelamin : 
    <input name="jk" type="radio" value="L">
    Pria
    <input name="jk" type="radio" value="P">
    Wanita
  </p>
  
  <p>No HP</br>
    <input name="nohp" type="text" id="nohp" style="width:97.2%;">
  </p>
  <p>Foto</br>
  <input name="foto" type="file" id="foto" />
  <p>&nbsp;</p>
</form>
<p align="center" style="color:#F00;">
  <input name="simpan" type="submit" id="simpan" value="SIMPAN DATA MEKANIK" />
<?php
if($_POST["simpan"]){
	$nmfoto = $_FILES["foto"]["name"];
	$lokfoto = $_FILES["foto"]["tmp_name"];
	if(!empty($lokfoto)){
		move_uploaded_file($lokfoto, "../fotomekanik/$nmfoto");
		}
  if($_POST[username]!=null&&$_POST[password]!=null&&$_POST[nama]!=null&&$_POST[nohp]!=null){
	if($_POST[password]==$_POST[password2]){
	  $sqlmk = mysql_query("insert into mekanik (username, password, namamekanik, jk, nohp, foto, status) values ('$_POST[username]', '$_POST[password]', '$_POST[nama]', '$_POST[jk]', '$_POST[nohp]', '$nmfoto', 'Standby')");
	  if($sqlmk){
		echo "Data Mekanik Telah Ditambah";
	  }else{
		echo "Data Mekanik Gagal Ditambah!!!";
	  }
	echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=mekanik'>";
	}else{
	  echo "Password tidak Cocok!!!";
	}
  }else{
	echo "Data Tidak Lengkap!!!";
  }
}

	


//$sqla = mysql_query("insert into admin (username, password, namaadmin) values ('$_POST[username]', '$_POST[password]', '$_POST[nama]')");
?>
</p>
</fieldset>