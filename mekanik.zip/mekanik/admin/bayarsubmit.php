<?php
include "koneksi.php";
$sqlp= mysql_query("select * from pemesanan where kdpemesanan = '$_GET[kdp]'");
while($rp=mysql_fetch_array($sqlp)){
  $sqlmk=mysql_query("select * from mekanik where idmekanik = '$rp[idmekanik]'");
  $rmk=mysql_fetch_array($sqlmk);
  $totalbayar=$rp[harga];
}
$sqlp2= mysql_query("select * from pemesanan where kdpemesanan = '$_GET[kdp]'");
$rp2=mysql_fetch_array($sqlp2);
$sqlp3=mysql_query("update pemesanan set status='finish' where kdpemesanan='$_GET[kdp]'");
$sqlp4= mysql_query("select * from pemesanan where kdpemesanan = '$_GET[kdp]'");
while ($rp4=mysql_fetch_array($sqlp4)){
 $sqlmk=mysql_query("update mekanik set status='Standby' where idmekanik='$rp4[idmekanik]'");
 }
echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=transaksi'>";
?>