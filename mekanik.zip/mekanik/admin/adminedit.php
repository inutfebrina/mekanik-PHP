<?php
include "koneksi.php";
$sqla = mysql_query("select * from admin where idadmin = '$_GET[ida]'");
$ra=mysql_fetch_array($sqla);
?>
<fieldset style="width:92.2%;margin-top:-32px;">
<form name="form1" method="post" action="" enctype="multipart/form-data">
  <p align="center" style="background-color:#494949;color:#fff;font-family:Hobo Std;font-size:20px;box-shadow:0 0 2px #000;width:99.8%;"><u>TAMBAH DATA ADMIN</u></p>
  <input type="hidden" name="idadmin" value="<?php echo "$ra[idadmin]"; ?>">
  <p>Username</br>
    <input name="username" type="text" id="username" style="width:97.2%;" value="<?php echo "$ra[username]" ?>">
  </p>
  <p>Password</br> 
    <input name="password" type="password" id="password" style="width:97.2%;" value="<?php echo "$ra[password]" ?>">
  </p>
  <p>Konfirmasi Password</br>
    <input name="password2" type="password" id="password" style="width:97.2%;" value="<?php echo "$ra[password]" ?>">
  </p>
  <p>Nama Lengkap</br>
    <input name="nama" type="text" id="nama" style="width:97.2%;" value="<?php echo "$ra[namaadmin]" ?>">
  </p>
  <p>
    <input name="update" type="submit" id="update" value="UPDATE DATA ADMIN">
</p>
</form>
<p align="center" style="color:#F00;">
<?php
if($_POST["update"]){
  if($_POST[username]!=null&&$_POST[password]!=null&&$_POST[nama]!=null){
	if($_POST[password]==$_POST[password2]){
	  include "koneksi.php";
	  $sqla = mysql_query("update admin set username='$_POST[username]', password='$_POST[password]', namaadmin='$_POST[nama]' where idadmin='$_POST[idadmin]'");
	  if($sqla){
		echo "Data Admin Telah Diupdate";
	  }else{
		echo "Data Admin Gagal Diupdate!!!";
	  }
	echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=admin'>";
	}else{
	  echo "Password tidak Cocok!!!";
	}
  }else{
	echo "Data Tidak Lengkap!!!";
  }
}
?>