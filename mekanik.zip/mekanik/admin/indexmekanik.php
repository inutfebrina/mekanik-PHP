
<?php

?>
<body>
<form name="form0" method="post" action="" enctype="multipart/form-data">
<div class="container1">
  <div id="judul">
	Welcome Mekanik User
  </div>
</div>
<div class="container2">
  <div class="grid">
    <div class="dh3">
      <ul id="menu">
        <li><a href="<?php echo"?p=home"; ?>">Beranda</a></li>
	    <li><a href="<?php echo"?p=pemesanan"; ?>">Pemesanan</a></li>
		 <li><a href="<?php echo"?p=transaksi"; ?>">Transaksi</a></li>
	    <li><a href="<?php echo"?p=logout"; ?>">Logout</a></li>
      </ul>
    </div>
    
    <div class="dh9">
	  <div id="isiadmin">
		<?php
		  if($_GET["p"] == "logout"){
		 	 include "logout.php"; 
		  }else if($_GET["p"] == "pemesanan"){
		 	 include "pemesanan.php"; 
		  }else if($_GET["p"] == "transaksi"){
		 	 include "transaksi.php";
		  }else if($_GET["p"] == "codsubmit"){
		 	 include "codsubmit.php";
		  }else if($_GET["p"] == "bayarsubmit"){
		 	 include "bayarsubmit.php";
		  }else if($_GET["p"] == "home"){
		 	 include "home.php";
		  }
		?>
      </div>
    </div>
    
  </div>
</div>

</form>
</body>