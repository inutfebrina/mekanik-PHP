<div class="container4" style="margin-top:-15px;color:#000">
  <div class="grid">
  <div class="dh12">
<?php
include "koneksi.php";
$sqlp = mysql_query("select * from pemesanan order by idmember");
$kdpemesanan=null;
$_POST["$kdpemesanan"]=null;
while($rp=mysql_fetch_array($sqlp)){
  if($kdpemesanan==$rp["kdpemesanan"]){
	continue;
  }
  $sqlm = mysql_query("select * from member where idmember='$rp[idmember]'");
  $rm = mysql_fetch_array($sqlm);
  echo "<div class='dh4' style='min-height:430px;'>";
    echo "<div id='border'>";
	  echo "<div id='jdlborder' align='center'>";
	  echo "<b>$rp[kdpemesanan]</b>";
	  echo "</div>";
	  echo "<div id='isiborder'>";
	  echo "<p>Ordered by: $rm[nama]</br>Nohp: $rm[nohp]</p>";
	  echo "<p>Nama Penerima: $rp[nama]</br>Nohp: $rp[nohp]</p>";
	  echo "<p><p style='margin-bottom:0px;text-align:center;'>|Mekanik Yang Dipesan|</p>";
	  echo "<table id='wborder3' border='0' cellpadding='10'>";
	  echo "<tr>";
	  echo "<th>No</th>";
	  echo "<th>Mekanik</th>";
	  echo "<th>No HP</th>";
	  echo "</tr>";
	  $kdpemesanan=$rp["kdpemesanan"];
	  $btnstatus=$rp["status"];
	  $no=0;
	  $total=0;
	  $sqlp2= mysql_query("select * from pemesanan where kdpemesanan='$rp[kdpemesanan]'");
	  while($rp2=mysql_fetch_array($sqlp2)){
		$no++;
		$sqls = mysql_query("select * from mekanik where idmekanik='$rp2[idmekanik]'");
	    $rs = mysql_fetch_array($sqls);
		echo "<tr>";
		echo "<td>$no</th>";
		echo "<td>$rs[namamekanik]</td>";
		echo "<td>$rs[nohp]</td>";
		echo "</tr>";
		$total=$rp2["harga"];
	  }
	  echo "</table>Total Harga: Rp.$total</p>";
	  echo "Alamat: $rp[alamat]</br>";
	  echo "Catatan: $rp[catatan]</br></p>";
	  if($rp["status"]=="sudah"){
		$stat="<b style='color:green;'>Sudah Dibayar</b>";
		$btn="<input type='submit' name='$kdpemesanan' value='Submit Transaksi' style='background-color:green;'>";
		$codlink="";
	  }else if($rp["status"]=="cash"){
		$stat="<b style='color:green;'>On Process</b>";
		$btn="<input type='submit' name='$kdpemesanan' value='Batalkan Pemesanan' style='background-color:red;'>";
		$codlink="<a href='?p=codsubmit&kdp=$rp[kdpemesanan]'>Masukkan Total Harga</a>";
	  }else if($rp["status"]=="finish"){
		$stat="<b style='color:green;'>Sudah Bayar</b>";
		$btn="";
		$codlink="";
	  }else{
		$stat="<b style='color:red;'>Belum Dibayar</b>";
		$btn="<input type='submit' name='$kdpemesanan' value='Batalkan Pemesanan' style='background-color:red;'>";
		$codlink="";
	  }
	  echo "<p align='center'>Status: $stat</p>";
	  echo "<p style='width:96%'>$btn</br></p>";
	  echo "<p style='width:96%'>$codlink</br></p>";
	  if(isset($_POST["$kdpemesanan"])){
	  if($_POST["$kdpemesanan"]){
		if($rp[status]=="sudah"){
		  echo "ini untuk submit transaksi $rp[kdpemesanan]";
		  echo "<META HTTP-EQUIV='Refresh' Content='2; URL=?p=bayarsubmit&kdp=$rp[kdpemesanan]'>";
		}else{
		  $sqlp4 = mysql_query("select * from pemesanan where kdpemesanan='$rp[kdpemesanan]'");
		  while($rp4=mysql_fetch_array($sqlp4)){
			$sqls2=mysql_query("select * from mekanik where idmekanik='$rp4[idmekanik]'");
			$rs2=mysql_fetch_array($sqls2);
			$stoktambah=$rs2[stok]+1;
			$sqlmk3=mysql_query("update mekanik set status='Standby' where idmekanik='$rp4[idmekanik]'");
		  }
		  $sqlp5=mysql_query("delete from pemesanan where kdpemesanan='$kdpemesanan'");
		  if($sqlp5){
			echo "pemesanan dengan kode $rp[kdpemesanan] telah dibatalkan</br>mekanik kembali ke Stoknya";
		  }
		   echo "<META HTTP-EQUIV='Refresh' Content='2; URL=?p=pemesanan'>";
		}
	  }
	  }
	  echo "</div>";
    echo "</div>";
  echo "</div>";
  
}
?>
    </div>
  </div>
</div>