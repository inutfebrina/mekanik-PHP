<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "db_tde";
	
	$con = mysql_connect($host, $user, $pass);
	$condb = mysql_select_db($db, $con);
	/*
	if($con){
		echo "Koneksi Sukses";
		if($condb){
			echo "</br>database $db ada";
		}else{
			echo "</br>database $db tidak ada";
		}
	}else{
		echo "koneksi gagal";
	}
	*/
?>