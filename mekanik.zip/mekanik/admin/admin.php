<?php
include "koneksi.php";
$sqla = mysql_query("select * from admin order by idadmin asc");
?>
<a href="<?php echo "?p=adminadd"; ?>">Tambah Admin</a>
<p></p>
<table id="wborder" border="1" width="90%" cellpadding="10">
  <tr>
   <th>NO</th>
   <th>USERNAME</th>
   <th>PASSWORD</th>
   <th>NAME</th>
   <th>USER ID</th>
   <th>ACTION</th>
  </tr>
<?php
$no=0;
while($ra = mysql_fetch_array($sqla)){
  $no++;
  echo 
 "<tr height='50px'>
    <td>$no</td>
	<td>$ra[username]</td>
    <td>$ra[password]</td>
    <td>$ra[namaadmin]</td>
	<td>$ra[idadmin]</td>
    <td>
	  <a href='?p=adminedit&ida=$ra[idadmin]'>Ubah</a> | 
	  <a href='?p=admindel&ida=$ra[idadmin]'>Hapus</a>
	</td>
  </tr>";
  }
?>
</table>