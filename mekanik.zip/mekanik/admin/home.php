<?php
include "koneksi.php";
$sqlmk = mysql_query("select * from mekanik");
$jmlmk = 0;
while($rmk = mysql_fetch_array($sqlmk)){
  $jmlmk++;
}

$sqlm = mysql_query("select * from member");
$jmlm = 0;
while($rm = mysql_fetch_array($sqlm)){
  $jmlm++;
}

$sqlt = mysql_query("select * from transaksi");
$jmlt = 0;
$total = 0;
while($rt = mysql_fetch_array($sqlt)){
  $jmlt++;
  $total=$total+$rt["totalbayar"];
}
?>

  <div class="grid" style="color:#E0E0E0;" align="center">
    <div class="dh12" id="isiberanda" style="min-height:150px;background-color:#229922;margin-top:-10px;">
      <ul>
	    <a href="?p=mekanik">
        <div class="dh4" id="boxberanda">
	      <p>MEKANIK</p>
          <p>Total Mekanik :<?php echo "$jmlmk" ?></p>
	    </div>
	    </a>
		<a href="?p=member">
	    <div class="dh4" id="boxberanda">
	      <p>MEMBER</p>
          <p>Total Member : <?php echo "$jmlm" ?></p>
	    </div>
	    </a>
	    <a href="?p=transaksi">
	    <div class="dh4" id="boxberanda">
	      <p>TRANSAKSI</p>
          <p>Jumlah Transaksi : <?php echo "$jmlt" ?></p>
          <p>Total Transaksi : <?php echo "Rp.$total,-" ?></p>
	    </div>
	    </a>
	  </ul>
	</div>
  </div>
  