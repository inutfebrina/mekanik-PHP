<?php
if(!empty($_SESSION["usermbr"]) and !empty($_SESSION["passmbr"])){
?>
<div class="jisi2" align="center"><big>Pesanan Anda</big></div>
<table id='wborder' border="1" width="100%" cellpadding="10" align="center">
  <tr>
    <th width="10px">NO</th>
    <th width="100px">FOTO</th>
    <th>Nama Mekanik</th>
   
    <th>No HP</th>
	<th width="100px">AKSI</th>
  </tr>
<?php
$sqlk = mysql_query("select * from keranjang where idmember = '$rm[idmember]'");
$no=0;
while($rk = mysql_fetch_array($sqlk)){
	$sqlmk = mysql_query("select * from mekanik where idmekanik='$rk[idmekanik]'");
	$rmk=mysql_fetch_array($sqlmk);
	$no++;
	echo "<tr>";
	echo "<td>$no</td>";
	echo "<td><img src='fotomekanik/$rmk[foto]' width='90px' height='80px'></td>";
	echo "<td>$rmk[namamekanik]</td>";

	echo "<td>$rmk[nohp]</td>";
	echo "<td><a href='?p=keranjangdel&idk=$rk[idkeranjang]'>Batalkan Produk ini</a></td>";
	echo "</tr>";
}

?>
</table>
<div class="botisi">
  <div class="dh12">
    <div class="dh5">
	
<?php
echo "</div>";
?>
<form name="formkeranjang" method="post" action="" enctype="multipart/form-data">
<div class="dh3">
  <input name="tambahproduk" type="submit" id="btnpemesanan" value="Tambahkan Mekanik">
</div>
<?php
if($no>0){
?>
    <div class="dh3">
      <input name="mulaipemesanan" type="submit" id="btnpemesanan" value="Pesan Sekarang">
    </div>
<?php
}
?>
</form>
  </div>
</div>
<?php
if(isset($_POST["mulaipemesanan"])){
if($_POST["mulaipemesanan"]){
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=pemesananadd'>";
}
}
if(isset($_POST["tambahproduk"])){
if($_POST["tambahproduk"]){
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=mekanik'>";
}
}
}else{
  echo "Anda Harus Login atau Register Terlebih Dahulu";
  echo "<META HTTP-EQUIV='Refresh' Content='1; URL=?p=register'>";
}
?>
