<?php
include "koneksi.php";
?>

<div class="dh12" style="border:5px solid #000;color:#fff;color:#FFFFFF;background-color:#2c3031;padding-left:0px;margin-left:0px">
  <h3 align="center">Ada Masalah Dengan Performance Mesin Anda? Atau Kerusakan Mesin Tapi Tak Ingin Ribet? </h3>
  <h1 align="center"> -Beritahu Kami- </h1>
  </div>


<?php
$sqlmk = mysql_query("select * from mekanik order by idmekanik asc");

while($rmk = mysql_fetch_array($sqlmk)){
echo "<div class='dh6' align='center'>";
echo "<div id='prd'>";
echo "<fieldset>";
echo "<img src='fotomekanik/$rmk[foto]' width='40%'>";
echo "<h3>$rmk[namamekanik]</h3>";
echo "<h3>$rmk[keahlian]</h3>";
echo "<p><a href='?p=keranjangadd&idmk=$rmk[idmekanik]'><button type='button' class='btn btn-more'>Lihat Mekanik</button></a>";
echo "</fieldset>";
echo "</div>";
echo "</div>";
}
?>

